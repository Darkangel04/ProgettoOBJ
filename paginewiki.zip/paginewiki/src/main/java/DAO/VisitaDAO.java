package DAO;

import Model.Visita;

public interface VisitaDAO {
    public void insertView(Visita V);   // Metodo per inserire una nuova visita nel database
}
